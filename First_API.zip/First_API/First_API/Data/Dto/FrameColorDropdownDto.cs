﻿using System.ComponentModel.DataAnnotations;

namespace Ayloul.Areas.Admin.Models
{
    public class FrameColorDropdownDto
    {
        public int FrameColor_Id { get; set; }

        public string? img { get; set; }

        public string FrameColor_Color { get; set; }


    }
}
