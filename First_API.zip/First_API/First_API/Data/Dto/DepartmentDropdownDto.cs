﻿namespace First_API.Data.Dto
{
    public class DepartmentDropdownDto
    {
        public int DepartmentId { get; set; }
        public string DepartmentName { get; set; }
    }
}
