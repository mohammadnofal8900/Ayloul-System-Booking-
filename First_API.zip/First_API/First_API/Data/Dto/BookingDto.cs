﻿namespace First_API.Data.Dto
{
    public class BookingDto
    {
        public int Booking_id { get; set; }

        public string FullName { get; set; }
        public bool IsActive { get; set; }
        public string? Location { get; set; }
        public string PhoneNumber { get; set; } = null!;
        public int BookingNumber { get; set; }
        public DateTime DateTime { get; set; }
        public decimal TotalPrice { get; set; }
        public int CustomerId { get; set; }

        public DateTime OrderDate { get; set; }

        public PaymentMethodType? PaymentMethod { get; set; } = PaymentMethodType.Cash;
        public enum PaymentMethodType
        {
            Cash = 0,
            Visa = 1
        }
        public BookingStatus bookingStatus { get; set; } = BookingStatus.pending;


        
    }
}
