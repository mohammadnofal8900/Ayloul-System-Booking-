﻿namespace First_API.Data.Dto
{
    public class BookingViewDto
    {
        
        public int BookingId { get; set; }

        public string Name { get; set; } = null!;
        public string Description { get; set; } = null!;
        public string? EventDate { get; set; }

        public int LocationId { get; set; }

        public BookingStatus bookingStatus { get; set; }

        public List<int>? ServiceId { get; set; }

        public int? Background { get; set; }

        public int FrameColor { get; set; }

        public int RoseColor1_Id { get; set; }

        public int? RoseColor2_Id { get; set; }

        public int RoseType { get; set; }

        public string? Note { get; set; }

        public bool IsActive { get; set; }

        public string? NoteImage { get; set; }

public string FullName { get; set; }
        
        public int BookingNumber { get; set; }
        public DateTime DateTime { get; set; }
        public int BasePrice { get; set; }
        public string PhoneNumber { get; set; } = null!;
        
        public decimal TotalPrice { get; set; }
        public int CustomerId { get; set; }

        public DateTime OrderDate { get; set; }

        public PaymentMethodType? PaymentMethod { get; set; } = PaymentMethodType.Cash;
        public enum PaymentMethodType
        {
            Cash = 0,
            Visa = 1
        }
        
    }
}
