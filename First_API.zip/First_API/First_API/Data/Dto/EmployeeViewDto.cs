﻿using Ayloul.Data;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace First_API.Data.Dto
{
    public class EmployeeViewDto
    {


        [Key]

        public int Employee { get; set; }

        public string Full_Name { get; set; }

        public decimal Employee_Salary { get; set; }

        public string Employee_Email { get; set; }

        public string Mobile_Phone { get; set; }

        public DateTime Employee_Date { get; set; }

        [DefaultValue(true)]
        public bool Is_Active { get; set; } = true;

        public string RoleName { get; set; }

        public string? Employee_Img { get; set; }
        
        public string? Gender { get; set; }

        public string? Department { get; set; }

        public string? Location { get; set; }

        [DataType(DataType.Password)]
        public string Password { get; set; }

        public string ConfirmPassword { get; set; }

    }
}
