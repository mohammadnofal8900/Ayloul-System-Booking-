﻿namespace First_API.Data.Dto
{
    public class BookingEditDto
    {


        public int BookingId { get; set; }
        public string Name { get; set; }

        public string Description { get; set; } = null!;
        public string? EventDate { get; set; }
        public int LocationId { get; set; }
        public BookingStatus bookingStatus { get; set; } = BookingStatus.pending;
        public List<int>? ServiceId { get; set; }
        public int Background { get; set; }



        public int FrameColor { get; set; }
       

        public int RoseColor1_Id { get; set; }


        public int CustomerId { get; set; }
        public int? RoseColor2_Id { get; set; }
     


        public int RoseType { get; set; }

        public string? Note { get; set; }
        public bool IsActive { get; set; }
        
        public string? NoteImage { get; set; }
    
    }
}
