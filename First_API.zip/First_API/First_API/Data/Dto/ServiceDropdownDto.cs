﻿using System.ComponentModel.DataAnnotations;

namespace Ayloul.Areas.Admin.Models
{
    public class ServiceDropdownDto
    {
        public int Service_Id { get; set; }

        public string Service_Name { get; set; }

        public int Price { get; set; }

        public string? img { get; set; }
    }
}
