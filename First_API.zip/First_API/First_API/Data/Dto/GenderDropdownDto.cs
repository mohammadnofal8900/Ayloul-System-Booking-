﻿namespace First_API.Data.Dto
{
    public class GenderDropdownDto
    {

        public int GenderId { get; set; }
        public string GenderName { get; set; }
    }
}
