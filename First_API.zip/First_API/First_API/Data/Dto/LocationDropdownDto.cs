﻿namespace First_API.Data.Dto
{
    public class LocationDropdownDto
    {
        public int LocationId { get; set; }
        public string City { get; set; }

        public decimal Price { get; set; }
    }
}
