﻿namespace First_API.Data.Dto
{
    public enum BookingStatus
    {
        pending = 1,

        accepted = 2,

        completed = 4,

        cancelled = 5
    }
}
