﻿namespace Ayloul.Areas.Admin.Models
{
    public class BackgroundDropdownDto
    {
        public int BackgroundId { get; set; }
        public string BackgroundColor { get; set; } = null!;
        public string? img { get; set; } = null;


    }
}
