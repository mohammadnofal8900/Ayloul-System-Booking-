﻿namespace First_API.Data.Dto
{
    public class ServicesDto
    {
        public int Service_Id { get; set; }
        public string Service_Name { get; set; } = null!;
        public int Price { get; set; }
        public bool? Is_Active { get; set; }
        public string? Img { get; set; }

    }
}
