﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace First_API.Data.Dto
{
    public class EmployeesEditDto
    {


        [Key]

        public int Employee { get; set; }

        public string UserId { get; set; } = string.Empty;

        public string Full_Name { get; set; }

        public decimal Employee_Salary { get; set; }

        public string Employee_Email { get; set; }

        public string Mobile_Phone { get; set; }

        public DateTime Employee_Date { get; set; }

        [DefaultValue(true)]
        public bool Is_Active { get; set; } = true;

        public string RoleName { get; set; }

        public string? Employee_Img { get; set; }
        public int Gender_Id { get; set; }
        public int Department_Id { get; set; }

        public int Location_Id { get; set; }

        //[DataType(DataType.Password)]
        //public string Password { get; set; }

        //public string ConfirmPassword { get; set; }

    }
}
