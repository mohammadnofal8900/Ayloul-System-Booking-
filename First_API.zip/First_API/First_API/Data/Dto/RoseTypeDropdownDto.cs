﻿namespace Ayloul.Areas.Admin.Models
{
    public class RoseTypeDropdownDto
    {
        public int RoseType_Id { get; set; }
        public string RoseType_Name { get; set; }
        public string RoseType_Description { get; set; }
        public string? img { get; set; }
    }
}
