﻿using First_API.Data.Dto;

namespace First_API.Data.Dto2
{
    public class UserBookingEditDto
    {
        public int BookingId { get; set; }
        public int CustomerId { get; set; }
        public string Name { get; set; } = null!;

        public string PhoneNumber { get; set; } = null!;

        public DateTime DeliverDate { get; set; }

        public string Description { get; set; } = null!;

        public string? Note { get; set; }

        public string? NoteImage { get; set; }

        public string? EventDate { get; set; }

        public int LocationId { get; set; }

        public List<int>? ServiceId { get; set; }

        public int BackgroundId { get; set; }

        public int FrameColorId { get; set; }

        public int RoseColor1Id { get; set; }

        public int? RoseColor2Id { get; set; }

        public int RoseTypeId { get; set; }

        public IFormFile? ImageFile { get; set; }

       
        public decimal TotalPrice { get; set; }

    }
}
