﻿namespace First_API.Data.Dto2
{
    public class VisaPaymentRequestDto
    {
        public BookingConfirmationDto Booking { get; set; } = null!;

        public string CardHolderName { get; set; } = null!;
        public string CardNumber { get; set; } = null!;
        public string ExpiryDate { get; set; } = null!;
        public string CVV { get; set; } = null!;
    }
}
