﻿using System;
using System.Collections.Generic;
using Ayloul.Data;
using First_API.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace First_API.Data
{
    public partial class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext()
        {
        }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<AuditBooking> AuditBookings { get; set; } = null!;
        public virtual DbSet<Background> Backgrounds { get; set; } = null!;
        public virtual DbSet<Booking> Bookings { get; set; } = null!;
        public virtual DbSet<BookingService> BookingServices { get; set; } = null!;
        public virtual DbSet<ChatRoom> ChatRooms { get; set; } = null!;
        public virtual DbSet<Customer> Customers { get; set; } = null!;
        public virtual DbSet<Department> Departments { get; set; } = null!;
        public virtual DbSet<Employee> Employees { get; set; } = null!;
        public virtual DbSet<EmployeeAudit> EmployeeAudits { get; set; } = null!;
        public virtual DbSet<FrameColor> FrameColors { get; set; } = null!;
        public virtual DbSet<Gender> Genders { get; set; } = null!;
        public virtual DbSet<Location> Locations { get; set; } = null!;
        public virtual DbSet<Message> Messages { get; set; } = null!;
        public virtual DbSet<Payment> Payments { get; set; } = null!;
        public virtual DbSet<Rating> Ratings { get; set; } = null!;
        public virtual DbSet<RoseColor> RoseColors { get; set; } = null!;
        public virtual DbSet<RoseType> RoseTypes { get; set; } = null!;
        public virtual DbSet<Service> Services { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=DESKTOP-AGLU287;Database=Ayloul;Trusted_Connection=True;TrustServerCertificate=True");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Payment>(entity =>
            {
                entity.HasKey(e => e.PaymentId);

                entity.Property(e => e.PaymentId)
                    .HasColumnName("Payment_Id");

                entity.Property(e => e.BookingId)
                    .HasColumnName("Booking_Id");

                entity.Property(e => e.Amount)
                    .HasColumnType("decimal(18,2)");

                entity.Property(e => e.Currency)
                    .HasColumnName("Currency");

                entity.Property(e => e.PaymentMethod)
                    .HasColumnName("Payment_Method");

                entity.Property(e => e.TransactionId)
                    .HasColumnName("Transaction_Id");

                entity.Property(e => e.Status)
                    .HasColumnName("Status");

                entity.Property(e => e.PaymentDate)
                    .HasColumnName("Payment_Date");

                entity.HasOne(e => e.Booking)
                    .WithMany(b => b.Payments)
                    .HasForeignKey(e => e.BookingId);
            });


            modelBuilder.Entity<BookingService>(entity =>
            {
                entity.HasKey(e => e.BookingServiceId);

                entity.Property(e => e.BookingServiceId)
                    .HasColumnName("BookingService_Id");

                entity.Property(e => e.BookingId)
                    .HasColumnName("Booking_Id");

                entity.Property(e => e.ServiceId)
                    .HasColumnName("Service_Id");
            });

            modelBuilder.Entity<Background>(entity =>
            {
                entity.ToTable("Backgrounds");

                entity.HasKey(e => e.BackgroundId);

                entity.Property(e => e.BackgroundId)
                    .HasColumnName("Background_Id");

                entity.Property(e => e.BackgroundColor)
                    .HasColumnName("Background_Color");

                entity.Property(e => e.Img)
                    .HasColumnName("Img");
            });

            modelBuilder.Entity<FrameColor>(entity =>
            {
                entity.ToTable("FrameColors");

                entity.HasKey(e => e.FrameColorId);

                entity.Property(e => e.FrameColorId)
                    .HasColumnName("FrameColor_Id");

                entity.Property(e => e.FrameColorColor)
                    .HasColumnName("FrameColor_Color");

                entity.Property(e => e.Img)
                    .HasColumnName("Img");
            });

            modelBuilder.Entity<RoseType>(entity =>
            {
                entity.ToTable("RoseTypes");

                entity.HasKey(e => e.RoseTypeId);

                entity.Property(e => e.RoseTypeId)
                    .HasColumnName("RoseType_Id");

                entity.Property(e => e.RoseTypeName)
                    .HasColumnName("RoseType_Name");

                entity.Property(e => e.RoseTypeDescription)
                    .HasColumnName("RoseType_Description");

                entity.Property(e => e.Img)
                    .HasColumnName("Img");
            });

            modelBuilder.Entity<RoseColor>(entity =>
            {
                entity.ToTable("RoseColors");

                entity.HasKey(e => e.RoseColorId);

                entity.Property(e => e.RoseColorId)
                    .HasColumnName("RoseColor_Id");

                entity.Property(e => e.RoseColorName)
                    .HasColumnName("RoseColor_Name");

                entity.Property(e => e.Img)
                    .HasColumnName("Img");
            });

            modelBuilder.Entity<Customer>(entity =>
            {
                entity.ToTable("Customers");

                entity.HasKey(e => e.CustomerId);

                entity.Property(e => e.CustomerId)
                    .HasColumnName("Customer_Id");

                entity.Property(e => e.UserId)
                    .HasColumnName("UserId");

                entity.Property(e => e.Note)
                    .HasColumnName("Note");

                entity.Property(e => e.IsActive)
                    .HasColumnName("Is_Active");
            });


            modelBuilder.Entity<Booking>(entity =>
            {

                entity.HasOne(d => d.Customer)
    .WithMany(p => p.Bookings)
    .HasForeignKey(d => d.CustomerId)
    .OnDelete(DeleteBehavior.Restrict)
    .HasConstraintName("FK_Booking_Customer");

                entity.HasOne(d => d.RoseColor1)
                    .WithMany(p => p.BookingRoseColor1s)
                    .HasForeignKey(d => d.RoseColor1Id)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_Booking_RoseColor1");

                entity.HasOne(d => d.RoseColor2)
                    .WithMany(p => p.BookingRoseColor2s)
                    .HasForeignKey(d => d.RoseColor2Id)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_Booking_RoseColor2");
                entity.HasKey(e => e.BookingId);

                entity.Property(e => e.BookingId)
                    .HasColumnName("Booking_Id");

                entity.Property(e => e.BackgroundId)
                    .HasColumnName("Background_Id");

                entity.Property(e => e.FrameColorId)
                    .HasColumnName("FrameColor_Id");

                entity.Property(e => e.LocationId)
                    .HasColumnName("Location_Id");

                entity.Property(e => e.IsActive)
    .HasColumnName("Is_Active");

                entity.Property(e => e.RoseColor1Id)
                    .HasColumnName("RoseColor1_Id");

                entity.Property(e => e.RoseTypeId)
                    .HasColumnName("RoseType_Id");

                entity.Property(e => e.BookingNumber)
                    .HasColumnName("Booking_Number");

                entity.Property(e => e.DateTime)
                    .HasColumnName("Date_Time");

                entity.Property(e => e.EventDate)
                    .HasColumnName("Event_Date");

                entity.Property(e => e.NoteImage)
                    .HasColumnName("Note_Image");

                entity.Property(e => e.PhoneNumber)
                    .HasColumnName("Phone_Number");

                entity.Property(e => e.RoseColor2Id)
                    .HasColumnName("RoseColor2_Id");

                entity.Property(e => e.CustomerId)
                    .HasColumnName("Customer_Id");

                entity.Property(e => e.OrderDate)
                    .HasColumnName("Order_Date");

                entity.Property(e => e.BookingStatus)
                    .HasColumnName("bookingStatus");

                entity.Property(e => e.PaymentMethod)
                    .HasColumnName("paymentMethod");
            
        });

            modelBuilder.Entity<Department>(entity =>
            {
                entity.ToTable("Departments");

                entity.Property(e => e.DepartmentId)
                    .HasColumnName("Department_Id");

                entity.Property(e => e.DepartmentName)
                    .HasColumnName("Department_Name");
            });

            modelBuilder.Entity<Gender>(entity =>
            {
                entity.ToTable("Genders");
                entity.Property(e => e.GenderId)
       .HasColumnName("Gender_Id");
                entity.Property(e => e.GenderName)
                    .HasColumnName("Gender_Name");
            });


            modelBuilder.Entity<Location>(entity =>
            {
                entity.ToTable("Locations");
                entity.Property(e => e.LocationId)
        .HasColumnName("Location_Id");

                entity.Property(e => e.City)
                    .HasColumnName("City");

            });

            modelBuilder.Entity<Employee>(entity =>
            {

                entity.ToTable("Employees");

                entity.Property(e => e.EmployeeId)
                    .HasColumnName("Employee_Id");

                entity.Property(e => e.EmployeeSalary)
                    .HasColumnName("Employee_Salary");

                entity.Property(e => e.EmployeeEmail)
                    .HasColumnName("Employee_Email");

                entity.Property(e => e.EmployeeDate)
                    .HasColumnName("Employee_Date");

                entity.Property(e => e.IsActive)
                    .HasColumnName("Is_Active");

                entity.Property(e => e.EmployeeImg)
                    .HasColumnName("Employee_Img");

                entity.Property(e => e.GenderId)
                    .HasColumnName("Gender_Id");

                entity.Property(e => e.DepartmentId)
                    .HasColumnName("Department_Id");

                entity.Property(e => e.LocationId)
                    .HasColumnName("Location_Id");
                entity.Property(e => e.MobilePhone)
    .HasColumnName("Mobile_Phone");
            });

            




            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
