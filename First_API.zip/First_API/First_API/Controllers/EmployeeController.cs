﻿using Ayloul.Data;
using First_API.Data;
using First_API.Data.Dto;
using First_API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Threading.Tasks;

namespace First_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = "Bearer", Roles = "Super Admin")]




    public class EmployeeController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly UserManager<ApplicationUser> _userManager;

        public EmployeeController(UserManager<ApplicationUser> userManager, ApplicationDbContext context, RoleManager<IdentityRole> roleManager)
        {
            _userManager = userManager;
            _context = context;
            _roleManager = roleManager;
        }

        [HttpGet]
        public async Task<IActionResult> ViewEmplyees()
        {
            var employees = await _context.Employees
        .Include(x => x.User)
        .Include(x => x.Department)
        .Include(x => x.Location)
        .Include(x => x.Gender)
        .AsNoTracking()
        .ToListAsync();

            var result = new List<EmployeeViewDto>();

            foreach (var employee in employees)
            {
                var roles = await _userManager.GetRolesAsync(employee.User);

                var employeeDto = new EmployeeViewDto
                {
                    Employee = employee.EmployeeId,

                    Full_Name=employee.User.FUllName,

                    Employee_Salary = employee.EmployeeSalary,

                    Employee_Email = employee.EmployeeEmail,

                    Mobile_Phone = employee.MobilePhone,

                    Employee_Date = employee.EmployeeDate,

                    Is_Active = employee.IsActive,

                    Employee_Img = employee.EmployeeImg,

                    Gender = employee.Gender?.GenderName,
                    Department = employee.Department?.DepartmentName,
                    Location = employee.Location?.City,

                    RoleName = roles.FirstOrDefault() ?? "No Role"
                };

                result.Add(employeeDto);
            }



            return Ok(result);
        }


        [HttpPost]
        public async Task<IActionResult> Create(EmployysDto model)
        {
            model.Employee = 0;


            // البحث عن المستخدم بالبريد الإلكتروني
            var user = await _userManager.FindByEmailAsync(model.Employee_Email);

            if (user == null)
            {
                        return Conflict(" User Not Found . ");
                  

            }

            // التحقق إذا كان هذا المستخدم موظفًا بالفعل
            var employeeExists = await _context.Employees
                .AnyAsync(e => e.UserId == user.Id);


            if (employeeExists)
            {
                return Conflict("This employee already exists.");

            }


            // التأكد أن Department موجود
            var departmentExists = await _context.Departments
                .AnyAsync(d => d.DepartmentId == model.Department_Id);

            if (!departmentExists)
            {
                return BadRequest($"Department with ID {model.Department_Id} does not exist.");
            }

            // التأكد أن Gender موجود
            var genderExists = await _context.Genders
                .AnyAsync(g => g.GenderId == model.Gender_Id);

            if (!genderExists)
            {
                return BadRequest($"Gender with ID {model.Gender_Id} does not exist.");
            }
            // التأكد أن Location موجودة
            var locationExists = await _context.Locations
                .AnyAsync(l => l.LocationId == model.Location_Id);

            if (!locationExists)
            {
                return BadRequest($"Location with ID {model.Location_Id} does not exist.");
            }

            

            

            // إنشاء سجل الموظف
            Employee employee = new Employee
            {
                UserId = user.Id,
                DepartmentId = model.Department_Id,
                GenderId = model.Gender_Id,
                LocationId = model.Location_Id,
                EmployeeSalary = model.Employee_Salary,
                MobilePhone = model.Mobile_Phone,
                EmployeeEmail = model.Employee_Email,
                EmployeeDate = model.Employee_Date,
                IsActive = true
            };
            // إعطاء المستخدم الـ Role المختار
            if (!string.IsNullOrEmpty(model.RoleName))
            {
                if (!await _userManager.IsInRoleAsync(user, model.RoleName))
                {
                    await _userManager.AddToRoleAsync(user, model.RoleName);
                }
            }


            // حذف المستخدم من جدول Customers إذا كان موجودًا
            var customer = await _context.Customers
                .FirstOrDefaultAsync(c => c.UserId == user.Id);

            if (customer != null)
            {
                _context.Customers.Remove(customer);
            }

            _context.Employees.Add(employee);
            await _context.SaveChangesAsync();
            return NoContent();

        }


        [HttpGet("{id}")]
        public async Task<IActionResult> GetEmployee(int id)
        {
            var employee = await _context.Employees
        .AsNoTracking()
        .Include(x => x.User)
        .Include(x => x.Department)
        .Include(x => x.Location)
        .Include(x => x.Gender)
        .FirstOrDefaultAsync(x => x.EmployeeId == id);

            if (employee == null)
            {
                return NotFound("Employee not found .");
            }

            var userRoles = await _userManager.GetRolesAsync(employee.User);

            var result = new
            {
                EmployeeId = employee.EmployeeId,
                UserId = employee.UserId,

                Full_Name = employee.User.FUllName,

                Employee_Salary = employee.EmployeeSalary,
                Employee_Date = employee.EmployeeDate,
                Employee_Email = employee.EmployeeEmail,
                Mobile_Phone = employee.MobilePhone,

                Is_Active = employee.IsActive,
                Employee_Img = employee.EmployeeImg,

                Gender_Id = employee.GenderId,
                Department_Id = employee.DepartmentId,
                Location_Id = employee.LocationId,

                RoleName = userRoles.FirstOrDefault() ?? ""
            };

            return Ok(result);
        }


        [HttpPut("{id}")]
        public async Task<IActionResult> EmployeeUpdate(int id, EmployeesEditDto model)
        {
            // جلب الموظف
            var employee = await _context.Employees
                .FirstOrDefaultAsync(e => e.EmployeeId == id);

            if (employee == null)
            {
                return NotFound("Employee not found.");
            }

            // تعديل بيانات الموظف
            employee.EmployeeEmail = model.Employee_Email;
            employee.EmployeeSalary = model.Employee_Salary;
            employee.MobilePhone = model.Mobile_Phone;
            employee.EmployeeDate = model.Employee_Date;
            employee.IsActive = model.Is_Active;

            employee.DepartmentId = model.Department_Id;
            employee.GenderId = model.Gender_Id;
            employee.LocationId = model.Location_Id;

            await _context.SaveChangesAsync();


            // جلب المستخدم المرتبط بالموظف
            var user = await _userManager.FindByIdAsync(employee.UserId);

            if (user != null)
            {
                // تعديل بيانات المستخدم
                user.FUllName = model.Full_Name;
                user.Email = model.Employee_Email;
                user.UserName = model.Employee_Email;
                user.PhoneNumber = model.Mobile_Phone;

                var userResult = await _userManager.UpdateAsync(user);

                if (!userResult.Succeeded)
                {
                    return BadRequest(userResult.Errors);
                }


                // تعديل الـ Role
                var oldRoles = await _userManager.GetRolesAsync(user);

                if (oldRoles.Any())
                {
                    var removeResult = await _userManager.RemoveFromRolesAsync(user, oldRoles);

                    if (!removeResult.Succeeded)
                    {
                        return BadRequest(removeResult.Errors);
                    }
                }

                if (!string.IsNullOrWhiteSpace(model.RoleName))
                {
                    var roleExists = await _roleManager.RoleExistsAsync(model.RoleName);

                    if (!roleExists)
                    {
                        return BadRequest($"Role '{model.RoleName}' does not exist.");
                    }

                    var addResult = await _userManager.AddToRoleAsync(user, model.RoleName);

                    if (!addResult.Succeeded)
                    {
                        return BadRequest(addResult.Errors);
                    }
                }
            }

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEmployee(int id)
        {
            // 1. جلب الموظف
            var employee = await _context.Employees
                .FirstOrDefaultAsync(e => e.EmployeeId == id);

            if (employee == null)
            {
                return NotFound(new
                {
                    message = "Employee not found."
                });
            }

            // حفظ UserId قبل حذف Employee
            var userId = employee.UserId;

            // 2. جلب الـ User
            var user = await _userManager.FindByIdAsync(userId);

            if (user == null)
            {
                return NotFound(new
                {
                    message = "User not found."
                });
            }

            // 3. معرفة المستخدم الذي قام بعملية الحذف
            var deletedBy = Request.Headers["CurrentUserId"].FirstOrDefault();

            if (string.IsNullOrEmpty(deletedBy))
            {
                return Unauthorized(new
                {
                    message = "Unable to identify the current user."
                });
            }

            // 4. فتح Connection حتى يبقى Session Context
            await _context.Database.OpenConnectionAsync();

            try
            {
                // مهم جدًا للـ Trigger + EmployeeAudit
                await _context.Database.ExecuteSqlRawAsync(
                    "EXEC sp_set_session_context @key=N'CurrentUserId', @value={0}",
                    deletedBy
                );

                // 5. حذف الموظف
                // الـ Trigger الموجود على Employees سيعمل هنا
                _context.Employees.Remove(employee);

                await _context.SaveChangesAsync();


                // 6. إزالة Roles الحالية من المستخدم
                var roles = await _userManager.GetRolesAsync(user);

                if (roles.Any())
                {
                    var removeRolesResult =
                        await _userManager.RemoveFromRolesAsync(user, roles);

                    if (!removeRolesResult.Succeeded)
                    {
                        return BadRequest(new
                        {
                            message = "Employee deleted, but roles could not be removed.",
                            errors = removeRolesResult.Errors
                        });
                    }
                }


                // 7. التأكد أن المستخدم غير موجود في Customers
                var customerExists = await _context.Customers
                    .AnyAsync(c => c.UserId == user.Id);

                if (!customerExists)
                {
                    var customer = new Customer
                    {
                        UserId = user.Id
                    };

                    _context.Customers.Add(customer);

                    await _context.SaveChangesAsync();
                }

                return Ok(new
                {
                    message = "Employee deleted successfully and converted to Customer.",
                    employeeId = id,
                    userId = userId
                });
            }
            finally
            {
                await _context.Database.CloseConnectionAsync();
            }
        }

        [HttpGet("GetRoles")]
        public async Task<IActionResult> GetRoles()
        {
            var roles = await _roleManager.Roles
                .Select(r => r.Name)
                .Where(r => r != null)
                .ToListAsync();

            return Ok(roles);
        }


        [HttpGet("GetGenders")]
        public async Task<IActionResult> GetGenders()
        {
            var genders = await _context.Genders
                .Select(x => new GenderDropdownDto
                {
                    GenderId = x.GenderId,
                    GenderName = x.GenderName
                })
                .ToListAsync();

            return Ok(genders);
        }

        [HttpGet("GetDepartments")]
        public async Task<IActionResult> GetDepartments()
        {
            var departments = await _context.Departments
                .Select(x => new DepartmentDropdownDto
                {
                    DepartmentId = x.DepartmentId,
                    DepartmentName = x.DepartmentName
                })
                .ToListAsync();

            return Ok(departments);
        }


        [HttpGet("GetLocations")]
        public async Task<IActionResult> GetLocations()
        {
            var location = await _context.Locations
                .Select(x => new LocationDropdownDto
                {
                    LocationId = x.LocationId,
                    City = x.City
                })
                .ToListAsync();

            return Ok(location);
        }

    }
    }
