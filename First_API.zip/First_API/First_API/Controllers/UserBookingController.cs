﻿using Ayloul.Areas.Admin.Models;
using Ayloul.Data;
using First_API.Data;
using First_API.Data.Dto;
using First_API.Data.Dto2;
using First_API.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace First_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserBookingController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public UserBookingController(UserManager<ApplicationUser> userManager, ApplicationDbContext context)
        {
            _userManager = userManager;
            _context = context;
        }


        [HttpPost("AddBooking")]
        public async Task<IActionResult> AddBooking(
    [FromForm] UserBookingEditDto model)
        {
            // =========================
            // 1. Current User
            // =========================

            var userId = Request.Headers["X-User-Id"].FirstOrDefault();

            if (string.IsNullOrEmpty(userId))
                return Unauthorized();

            // =========================
            // 2. Get Customer
            // =========================

            var customer = await _context.Customers
                .FirstOrDefaultAsync(c => c.UserId == userId);

            if (customer == null)
                return NotFound("Customer not found.");

            // =========================
            // 3. Get Location
            // =========================

            var location = await _context.Locations
                .FirstOrDefaultAsync(l =>
                    l.LocationId == model.LocationId);

            if (location == null)
            {
                return BadRequest(new
                {
                    success = false,
                    message = "Location not found."
                });
            }

            // =========================
            // 4. Calculate Price
            // =========================

            decimal totalPrice = location.Price;

            if (model.ServiceId != null &&
                model.ServiceId.Count > 0)
            {
                var services = await _context.Services
                    .Where(s => model.ServiceId.Contains(s.Service_Id))
                    .ToListAsync();

                totalPrice += services.Sum(s => s.Price);
            }

            decimal serviceFees = 0.05m;
            decimal basePrice = 20m;

            totalPrice += serviceFees;
            totalPrice += basePrice;

            // =========================
            // 5. Create Confirmation DTO
            // =========================

            var confirmation = new BookingConfirmationDto
            {
                CustomerId = customer.CustomerId,

                Name = model.Name,
                PhoneNumber = model.PhoneNumber,
                
                DeliverDate = model.DeliverDate,
                Description = model.Description,

                Note = model.Note,
                NoteImage = model.NoteImage,

                EventDate = model.EventDate,

                LocationId = model.LocationId,
                City = location.City,
                LocationPrice = location.Price,

                BackgroundId = model.BackgroundId,
                FrameColorId = model.FrameColorId,

                RoseColor1Id = model.RoseColor1Id,
                RoseColor2Id = model.RoseColor2Id,
                RoseTypeId = model.RoseTypeId,

                ServiceId = model.ServiceId,

                BasePrice = basePrice,
                ServiceFees = serviceFees,
                TotalPrice = totalPrice
            };

            // =========================
            // ❌ NO SaveChanges
            // =========================

            return Ok(confirmation);



        }



        [HttpPost("ConfirmCash")]
        public async Task<IActionResult> ConfirmCash(
    [FromBody] BookingConfirmationDto model)
        {
            // =========================
            // 1. Current User
            // =========================

            var userId = Request.Headers["X-User-Id"].FirstOrDefault();

            if (string.IsNullOrEmpty(userId))
                return Unauthorized();


            // =========================
            // 2. Get Customer
            // =========================

            var customer = await _context.Customers
                .FirstOrDefaultAsync(c => c.UserId == userId);

            if (customer == null)
                return NotFound("Customer not found.");


            // =========================
            // 3. Create Booking
            // =========================

            var booking = new Booking
            {
                CustomerId = customer.CustomerId,
                BookingNumber = Random.Shared.Next(10000000, 99999999),
                Name = model.Name!,
                PhoneNumber = model.PhoneNumber!,

                Description = model.Description!,
                Note = model.Note,
                NoteImage = model.NoteImage,

                EventDate = model.EventDate,

                LocationId = model.LocationId,

                BackgroundId = model.BackgroundId,
                FrameColorId = model.FrameColorId,

                RoseColor1Id = model.RoseColor1Id,
                RoseColor2Id = model.RoseColor2Id,
                RoseTypeId = model.RoseTypeId,

                BasePrice = (int)model.BasePrice,
                TotalPrice = model.TotalPrice,

                OrderDate = DateTime.Now,
                DateTime = DateTime.Now,

                IsActive = true,

                BookingStatus = BookingStatus.pending,

                // Cash
                PaymentMethod = 0
            };


            // =========================
            // 4. Add Booking
            // =========================

            _context.Bookings.Add(booking);

            await _context.SaveChangesAsync();


            // =========================
            // 5. Add Services
            // =========================

            if (model.ServiceId != null &&
                model.ServiceId.Count > 0)
            {
                foreach (var serviceId in model.ServiceId.Distinct())
                {
                    var bookingService = new BookingService
                    {
                        BookingId = booking.BookingId,
                        ServiceId = serviceId
                    };

                    _context.BookingServices.Add(bookingService);
                }

                await _context.SaveChangesAsync();
            }


            // =========================
            // 6. Success
            // =========================

            return Ok(new
            {
                success = true,
                message = "Booking created successfully.",
                bookingId = booking.BookingId
            });

        }



        [HttpPost("ConfirmVisa")]
        public async Task<IActionResult> ConfirmVisa(
    [FromBody] VisaPaymentRequestDto model)
        {
            var userId = Request.Headers["X-User-Id"]
                .FirstOrDefault();

            if (string.IsNullOrEmpty(userId))
                return Unauthorized();

            var customer = await _context.Customers
                .FirstOrDefaultAsync(c => c.UserId == userId);

            if (customer == null)
                return NotFound("Customer not found.");

            if (model.Booking == null)
                return BadRequest("Booking data is missing.");

            // -----------------------------
            // Validate Visa data
            // -----------------------------

            if (string.IsNullOrWhiteSpace(model.CardHolderName))
                return BadRequest("Card holder name is required.");

            if (string.IsNullOrWhiteSpace(model.CardNumber))
                return BadRequest("Card number is required.");

            if (string.IsNullOrWhiteSpace(model.ExpiryDate))
                return BadRequest("Expiry date is required.");

            if (string.IsNullOrWhiteSpace(model.CVV))
                return BadRequest("CVV is required.");

            var cardNumber =
                model.CardNumber.Replace(" ", "");

            if (cardNumber.Length < 13 ||
                cardNumber.Length > 19 ||
                !cardNumber.All(char.IsDigit))
            {
                return BadRequest("Invalid card number.");
            }

            if (model.CVV.Length < 3 ||
                model.CVV.Length > 4 ||
                !model.CVV.All(char.IsDigit))
            {
                return BadRequest("Invalid CVV.");
            }

            // -----------------------------
            // Generate Booking Number
            // -----------------------------

            int bookingNumber;

            do
            {
                bookingNumber =
                    Random.Shared.Next(10000000, 99999999);
            }
            while (await _context.Bookings
                .AnyAsync(b => b.BookingNumber == bookingNumber));

            // -----------------------------
            // Create Booking
            // -----------------------------

            var booking = new Booking
            {
                CustomerId = customer.CustomerId,

                Name = model.Booking.Name!,
                PhoneNumber = model.Booking.PhoneNumber!,

                Description = model.Booking.Description!,
                Note = model.Booking.Note,
                NoteImage = model.Booking.NoteImage,

                EventDate = model.Booking.EventDate,

                LocationId = model.Booking.LocationId,

                BackgroundId = model.Booking.BackgroundId,
                FrameColorId = model.Booking.FrameColorId,

                RoseColor1Id = model.Booking.RoseColor1Id,
                RoseColor2Id = model.Booking.RoseColor2Id,
                RoseTypeId = model.Booking.RoseTypeId,

                BasePrice = (int)model.Booking.BasePrice,
                TotalPrice = model.Booking.TotalPrice,

                BookingNumber = bookingNumber,

                OrderDate = DateTime.Now,
                DateTime = DateTime.Now,

                IsActive = true,

                BookingStatus = BookingStatus.accepted,

                // Visa = 1
                PaymentMethod = 1
            };

            _context.Bookings.Add(booking);

            await _context.SaveChangesAsync();

            // -----------------------------
            // Booking Services
            // -----------------------------

            if (model.Booking.ServiceId != null &&
                model.Booking.ServiceId.Count > 0)
            {
                foreach (var serviceId in
                         model.Booking.ServiceId.Distinct())
                {
                    var bookingService = new BookingService
                    {
                        BookingId = booking.BookingId,
                        ServiceId = serviceId
                    };

                    _context.BookingServices.Add(bookingService);
                }

                await _context.SaveChangesAsync();
            }

            // -----------------------------
            // Create Payment
            // -----------------------------

            var transactionId =
                "TXN-" +
                Guid.NewGuid()
                    .ToString("N")[..12]
                    .ToUpper();

            var payment = new Payment
            {
                BookingId = booking.BookingId,

                Amount = booking.TotalPrice,

                Currency = "JOD",

                PaymentMethod = 1,

                TransactionId = transactionId,

                Status = 1,

                PaymentDate = DateTime.Now

            };

            _context.Payments.Add(payment);

            await _context.SaveChangesAsync();

            // -----------------------------
            // Response
            // -----------------------------

            return Ok(new
            {
                success = true,

                message =
                    "Booking and Visa payment completed successfully.",

                bookingId = booking.BookingId,

                bookingNumber = booking.BookingNumber,

                transactionId = transactionId
            });
        }










        [HttpGet("MyBookings")]
        public async Task<IActionResult> MyBookings()
        {
            // ==============================
            // Get current user
            // ==============================

            var userId = Request.Headers["X-User-Id"]
                .FirstOrDefault();

            if (string.IsNullOrEmpty(userId))
                return Unauthorized();


            // ==============================
            // Get Customer
            // ==============================

            var customer = await _context.Customers
                .FirstOrDefaultAsync(c => c.UserId == userId);

            if (customer == null)
                return NotFound("Customer not found.");


            // ==============================
            // Get Customer Bookings
            // ==============================

            var bookings = await _context.Bookings
                .Where(b =>
                    b.CustomerId == customer.CustomerId)

                .Include(b => b.Location)
                .Include(b => b.Background)
                .Include(b => b.FrameColor)
                .Include(b => b.RoseType)
                .Include(b => b.RoseColor1)
                .Include(b => b.RoseColor2)

                .Include(b => b.BookingServices)
                    .ThenInclude(bs => bs.Service)

                .OrderByDescending(b => b.OrderDate)

                .Select(b => new MyBookingDto
                {
                    BookingId = b.BookingId,

                    BookingNumber = b.BookingNumber,

                    Name = b.Name,

                    PhoneNumber = b.PhoneNumber,

                    Description = b.Description,

                    Note = b.Note,

                    NoteImage = b.NoteImage,

                    EventDate = b.EventDate,

                    DeliveryDate = b.DateTime,

                    OrderDate = b.OrderDate,

                    TotalPrice = b.TotalPrice,

                    BookingStatus = (int)b.BookingStatus,

                    PaymentMethod = b.PaymentMethod,

                    LocationName = b.Location != null
                        ? b.Location.City
                        : null,

                    
                    BackgroundName = b.Background != null
                        ? b.Background.BackgroundColor
                        : null,

                    FrameColorName = b.FrameColor != null
                        ? b.FrameColor.FrameColorColor
                        : null,

                    RoseTypeName = b.RoseType != null
                        ? b.RoseType.RoseTypeName
                        : null,

                    RoseColor1Name = b.RoseColor1 != null
                        ? b.RoseColor1.RoseColorName
                        : null,

                    RoseColor2Name = b.RoseColor2 != null
                        ? b.RoseColor2.RoseColorName
                        : null,

                    Services = b.BookingServices
                        .Select(bs => bs.Service.Service_Name)
                        .ToList()
                })

                .ToListAsync();


            return Ok(bookings);
        }









        [HttpGet("GetLocations")]
        public async Task<IActionResult> GetLocations()
        {
            var location = await _context.Locations
                .Select(x => new LocationDropdownDto
                {
                    LocationId = x.LocationId,
                    City = x.City,
                    Price = x.Price,
                })
                .ToListAsync();

            return Ok(location);
        }

        [HttpGet("GetServices")]
        public async Task<IActionResult> GetServices()
        {
            var services = await _context.Services
                .Select(x => new ServiceDropdownDto
                {
                    Service_Id = x.Service_Id,
                    Service_Name = x.Service_Name,
                    Price = x.Price,
                    img=x.Img
                    
                    
                })
                .ToListAsync();

            return Ok(services);
        }


        [HttpGet("GetBachground")]
        public async Task<IActionResult> GetBachground()
        {
            var background = await _context.Backgrounds
                .Select(x => new BackgroundDropdownDto
                {
                    BackgroundId = x.BackgroundId,
                    BackgroundColor = x.BackgroundColor,
                    img=x.Img
                    
                })
                .ToListAsync();

            return Ok(background);
        }

        [HttpGet("GetRoseColor")]
        public async Task<IActionResult> GetRoseColor()
        {
            var roseColor = await _context.RoseColors
                .Select(x => new RoseColorDropdownDto
                {
                    RoseColor_Id = x.RoseColorId,
                    RoseColor_Name = x.RoseColorName,
                    img=x.Img
                })
                .ToListAsync();

            return Ok(roseColor);
        }

        [HttpGet("GetRoseType")]
        public async Task<IActionResult> GetRoseType()
        {
            var roseType = await _context.RoseTypes
                .Select(x => new RoseTypeDropdownDto
                {
                    RoseType_Id = x.RoseTypeId,
                    RoseType_Name = x.RoseTypeName
                })
                .ToListAsync();

            return Ok(roseType);
        }
        [HttpGet("GetFrameColor")]
        public async Task<IActionResult> GetFrameColor()
        {
            var frameColor = await _context.FrameColors
                .Select(x => new FrameColorDropdownDto
                {
                    FrameColor_Id = x.FrameColorId,
                    FrameColor_Color = x.FrameColorColor,
                    img = x.Img
                    
                })
                .ToListAsync();

            return Ok(frameColor);
        }


    }
}
