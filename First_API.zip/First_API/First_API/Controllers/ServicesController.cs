﻿using First_API.Data;
using First_API.Data.Dto;
using First_API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace First_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = "Bearer", Roles = "Super Admin")]

    public class ServicesController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public ServicesController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllService()
        {
            var service=await _context.Services.AsNoTracking().
                Select(x => new
            {
                x.Service_Id,
                x.Service_Name,
                x.Price,
                x.Img,
                x.Is_Active
            })
                .ToListAsync();
            return Ok(service);
        }


        [HttpPost]
        public async Task<IActionResult> create([FromForm] ServicesDto model)
        {
            model.Service_Id = 0;
           
            var service = new Service
            {
                Service_Name = model.Service_Name,
                Price = model.Price,
                Img = model.Img,
                Is_Active = model.Is_Active

            };
            _context.Services.Add(service);
            await _context.SaveChangesAsync();
            model.Service_Id=service.Service_Id;
            return CreatedAtAction(nameof(GetAllService),new {id=service.Service_Id},model);
        }


        [HttpGet("{id}")]
        public async Task<IActionResult> GetService(int id)
        {
            var services = await _context.Services.AsNoTracking().Where(x => x.Service_Id==id).
                Select(x => new ServicesDto 
                {
                    Service_Id=x.Service_Id,
                    Service_Name=x.Service_Name,
                    Price = x.Price,
                    Img = x.Img,
                    Is_Active = x.Is_Active
                    
                    
                })
                .ToListAsync();
            return Ok(services);
        }
        
        
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromForm] ServicesDto model)
        {
            var services=await _context.Services.FindAsync(id);
            if (services == null)
            {
                return NotFound();
            }


            services.Service_Name = model.Service_Name;
            services.Price = model.Price;
            services.Img = model.Img;
            services.Is_Active = model.Is_Active;

            
           
            await _context.SaveChangesAsync();
        
            return NoContent();
        }


        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteService(int id)
        {
            var Services = await _context.Services.FindAsync(id);
            if (Services == null) 
            {
                return NotFound();
            }

            var databooking=await _context.BookingServices.AnyAsync(x=>x.ServiceId==id);

            if (databooking)
            {
                return Conflict("Service Cannot Delete ");
            }
            _context.Services.Remove(Services);
            await _context.SaveChangesAsync();
            return NoContent();
        }

    }
}
