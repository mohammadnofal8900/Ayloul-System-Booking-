﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Ayloul.Data;
using First_API.Data;
using First_API.Data.Dto;
using First_API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Threading.Tasks;
using Ayloul.Areas.Admin.Models;
namespace First_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = "Bearer", Roles = "Super Admin")]

    public class BookingController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public BookingController(UserManager<ApplicationUser> userManager, ApplicationDbContext context)
        {
            _userManager = userManager;
            _context = context;
        }

        [HttpGet("status/{status}")]
        public async Task<IActionResult> GetBookingsByStatus(BookingStatus status)
        {
            var bookings = await _context.Bookings
    .Where(b => b.BookingStatus == status)
    .Include(b => b.Customer)
        .ThenInclude(c => c.User)
    .Include(b => b.BookingServices)
        .ThenInclude(bs => bs.Service)
    .Include(b => b.Location)
    .Include(b => b.Background)
    .Include(b => b.FrameColor)
    .Include(b => b.RoseType)
    .Include(b => b.RoseColor1)
    .Include(b => b.RoseColor2)
    .AsNoTracking()
    .ToListAsync();
            var result = new List<BookingDto>();

            foreach (var booking in bookings)
            {

                var bookingDto = new BookingDto
                {
                    Booking_id=booking.BookingId,
                    FullName = booking.Customer?.User?.Email ?? "",

                    IsActive = booking.IsActive,
                    BookingNumber = booking.BookingNumber,
                    DateTime = booking.DateTime,
                    PhoneNumber = booking.PhoneNumber,
                    TotalPrice = booking.TotalPrice,
                    CustomerId = booking.CustomerId,
                    OrderDate = booking.OrderDate,
                    Location = booking.Location?.City,

                    PaymentMethod = booking.PaymentMethod.HasValue
                        ? (BookingDto.PaymentMethodType)booking.PaymentMethod.Value
                        : BookingDto.PaymentMethodType.Cash,

                    bookingStatus = booking.BookingStatus
                };


                result.Add(bookingDto);
            }

            return Ok(result);
        }


        [HttpGet("{id}")]
        public async Task<IActionResult> GetBookingById(int id)
        {
            var booking = await _context.Bookings
                .AsNoTracking()

                .Include(b => b.Customer)
                .Include(b => b.BookingServices)
                    .ThenInclude(bs => bs.Service)
                .Include(b => b.Customer)
        .ThenInclude(c => c.User)
                .Include(b => b.Location)
                .Include(b => b.Background)
                .Include(b => b.FrameColor)
                .Include(b => b.RoseType)
                .Include(b => b.RoseColor1)
                .Include(b => b.RoseColor2)
                .FirstOrDefaultAsync(x => x.BookingId == id);

            if (booking == null)
            {
                return NotFound("Booking not found");
            }




            var result = new BookingViewDto
            {
                CustomerId=booking.CustomerId,
                BookingId=booking.BookingId,
                Description = booking.Description,
                Note = booking.Note,
                IsActive = booking.IsActive,
                BookingNumber = booking.BookingNumber,
                DateTime = booking.DateTime,
                BasePrice = booking.BasePrice,
                EventDate = booking.EventDate,
                Name = booking.Name,
                NoteImage = booking.NoteImage,
                PhoneNumber = booking.PhoneNumber,
                TotalPrice = booking.TotalPrice,
                OrderDate = booking.OrderDate,
                PaymentMethod = booking.PaymentMethod.HasValue
                    ? (BookingViewDto.PaymentMethodType)booking.PaymentMethod.Value
                    : BookingViewDto.PaymentMethodType.Cash,

                bookingStatus = booking.BookingStatus,

                ServiceId = await _context.BookingServices
            .Where(bs => bs.BookingId == booking.BookingId)
            .Select(bs => bs.ServiceId)
            .ToListAsync(),

                LocationId = booking.LocationId,
                FrameColor = booking.FrameColorId,
                RoseType = booking.RoseTypeId,
                Background = booking.BackgroundId.Value,

                RoseColor1_Id = booking.RoseColor1Id,
                RoseColor2_Id = booking.RoseColor2Id,
            };


            return Ok(result);
        }



        [HttpPut("{id}")]
        public async Task<IActionResult> EditBooking([FromForm] BookingEditDto model, int id)
        {


            var Booking = await _context.Bookings.FirstOrDefaultAsync(b => b.BookingId == id);
            if (Booking == null)
            {
                return NotFound("Booking not found.");
            }
            Booking.BookingId = model.BookingId;
            Booking.Name = model.Name;
            Booking.Description = model.Description;
            Booking.EventDate = model.EventDate;
            Booking.BookingStatus = model.bookingStatus;
            Booking.LocationId = model.LocationId;
            Booking.BackgroundId = model.Background;
            Booking.Note = model.Note;
            Booking.NoteImage = model.NoteImage;
            Booking.IsActive = model.IsActive;

            if (model.CustomerId == null || model.CustomerId == 0)
            {
                return BadRequest(new
                {
                    success = false,
                    message = "you can not Booking"
                });
            }

            Booking.CustomerId = model.CustomerId;


            Booking.RoseColor1Id = model.RoseColor1_Id;
            Booking.RoseColor2Id = model.RoseColor2_Id;
            Booking.RoseTypeId = model.RoseType;
            Booking.FrameColorId = model.FrameColor;

            var location = await _context.Locations
        .FirstOrDefaultAsync(l => l.LocationId == model.LocationId);

            if (location == null)
            {
                return BadRequest(new
                {
                    success = false,
                    message = "Location not found."
                });
            }


            decimal totalPrice = location.Price;

            if (model.ServiceId != null && model.ServiceId.Count > 0)
            {
                var services = await _context.Services
                    .Where(s => model.ServiceId.Contains(s.Service_Id))
                    .ToListAsync();

                totalPrice += services.Sum(s => s.Price);
            }
            else
            {
                model.ServiceId = null;
            }
            decimal Service_Fees = 0.05m;

            int BasePrice = 20;

            totalPrice += Service_Fees;
            totalPrice += BasePrice;

            Booking.TotalPrice = totalPrice;




            var oldServices = await _context.BookingServices
    .Where(bs => bs.BookingId == Booking.BookingId)
    .ToListAsync();

            _context.BookingServices.RemoveRange(oldServices);

            if (model.ServiceId != null)
            {
                foreach (var serviceId in model.ServiceId.Distinct())
                {
                    _context.BookingServices.Add(new BookingService
                    {
                        BookingId = Booking.BookingId,
                        ServiceId = serviceId
                    });
                }
            }

            await _context.SaveChangesAsync();

            return NoContent();

        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteBooking(int id)
        {
            var booking = await _context.Bookings
        .FirstOrDefaultAsync(b => b.BookingId == id);

            if (booking == null)
            {
                return NotFound(new
                {
                    message = "Booking not found."
                });
            }
            
            // الموظف الحالي
            var user = await _userManager.GetUserAsync(User);

            if (user == null)
            {
                return Unauthorized(new
                {
                    message = "User is not logged in."
                });
            }

            // إرسال اسم الموظف إلى SQL Session Context
            await _context.Database.OpenConnectionAsync();

            await _context.Database.ExecuteSqlRawAsync(
                "EXEC sp_set_session_context @key=N'UserName', @value={0}",
                user.UserName
            );


            _context.Bookings.Remove(booking);

            await _context.SaveChangesAsync();

            return Ok(new
            {
                message = "Booking deleted successfully.",
                deletedBy = user.UserName,
                bookingId = id
            });




        }





        [HttpGet("GetLocations")]
        public async Task<IActionResult> GetLocations()
        {
            var location = await _context.Locations
                .Select(x => new LocationDropdownDto
                {
                    LocationId = x.LocationId,
                    City = x.City,
                    Price = x.Price,
                })
                .ToListAsync();

            return Ok(location);
        }

        [HttpGet("GetServices")]
        public async Task<IActionResult> GetServices()
        {
            var services = await _context.Services
                .Select(x => new ServiceDropdownDto
                {
                    Service_Id = x.Service_Id,
                    Service_Name = x.Service_Name,
                    Price = x.Price
                })
                .ToListAsync();

            return Ok(services);
        }

       
        [HttpGet("GetBachground")]
        public async Task<IActionResult> GetBachground()
        {
            var background = await _context.Backgrounds
                .Select(x => new BackgroundDropdownDto
                {
                    BackgroundId = x.BackgroundId,
                    BackgroundColor = x.BackgroundColor
                })
                .ToListAsync();

            return Ok(background);
        }

        [HttpGet("GetRoseColor")]
        public async Task<IActionResult> GetRoseColor()
        {
            var roseColor = await _context.RoseColors
                .Select(x => new RoseColorDropdownDto
                {
                    RoseColor_Id = x.RoseColorId,
                    RoseColor_Name = x.RoseColorName
                })
                .ToListAsync();

            return Ok(roseColor);
        }

        [HttpGet("GetRoseType")]
        public async Task<IActionResult> GetRoseType()
        {
            var roseType = await _context.RoseTypes
                .Select(x => new RoseTypeDropdownDto
                {
                    RoseType_Id = x.RoseTypeId,
                    RoseType_Name = x.RoseTypeName
                })
                .ToListAsync();

            return Ok(roseType);
        }
        [HttpGet("GetFrameColor")]
        public async Task<IActionResult> GetFrameColor()
        {
            var frameColor = await _context.FrameColors
                .Select(x => new FrameColorDropdownDto
                {
                    FrameColor_Id = x.FrameColorId,
                    FrameColor_Color = x.FrameColorColor
                })
                .ToListAsync();

            return Ok(frameColor);
        }

    }
}