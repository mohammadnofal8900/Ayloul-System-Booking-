﻿using Ayloul.Areas.User.Models;
using Ayloul.Data;
using First_API.Data;
using First_API.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Query;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace First_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly ApplicationDbContext _context;
        private readonly IConfiguration _configuration;
        private bool lockoutOnFailure;
        

        public AuthController(UserManager<ApplicationUser> userManager, SignInManager<ApplicationUser> signInManager, ApplicationDbContext context, IConfiguration configuration, RoleManager<IdentityRole> roleManager)
        {
            _context = context;
            _userManager = userManager;
            _signInManager = signInManager;
            _configuration = configuration;
            _roleManager = roleManager;
        }

        [HttpPost("Login")]
        public async Task<IActionResult> Login(LoginDto model)
        {
            var user =await _userManager.FindByEmailAsync(model.Email);
            if (user == null || !user.Is_Active || !await _userManager.CheckPasswordAsync(user,model.Password))
            {
                return Unauthorized("Email or Password is incorrect");
            }
            var role=await _userManager.GetRolesAsync(user);
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier,user.Id),
                new Claim("FullName", user.FUllName ?? ""),
                new Claim(ClaimTypes.Email,user.Email??""),

            };
            //لانو ممكن يكون الو اكثر من صلاحيه
            foreach (var item in role) 
            {
                claims.Add(new Claim(ClaimTypes.Role, item));
            }


            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]!));
            var token = new JwtSecurityToken(
                issuer: _configuration["Jwt:Issuer"],
                audience: _configuration["Jwt:Audience"],
                claims: claims,
                expires:DateTime.UtcNow.AddHours(2),
                signingCredentials:new SigningCredentials(key,SecurityAlgorithms.HmacSha256)

                );


            return Ok(new
            {
                token = new JwtSecurityTokenHandler().WriteToken(token),
                expiration = token.ValidTo,
                Message = "Login completed successfully"
            });

        }


       
        [HttpPost("Register")]
        public async Task<IActionResult> Register(RegesterDto model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            // التحقق من وجود البريد الإلكتروني
            var emailExists = await _userManager.FindByEmailAsync(model.Email);

            if (emailExists != null)
            {
                return BadRequest("Email already exists.");
            }

            // إنشاء المستخدم
            var user = new ApplicationUser
            {
                UserName = model.Email,
                Email = model.Email,
                FUllName = model.Full_Name,
                Is_Active = true
            };

            // إنشاء المستخدم مع كلمة المرور
            var result = await _userManager.CreateAsync(
                user,
                model.Password);

            if (!result.Succeeded)
            {
                return BadRequest(result.Errors);
            }

            var customer = new Customer 
            {
                UserId = user.Id,
                IsActive = true
            };
            _context.Customers.Add(customer);
            
            await _context.SaveChangesAsync();

            //// إضافة Role افتراضي للمستخدم
            //await _userManager.AddToRoleAsync(user, "User");

            // الحصول على Roles الخاصة بالمستخدم
            var roles = await _userManager.GetRolesAsync(user);

            

            // إنشاء Claims
            var claims = new List<Claim>
    {
        new Claim(
            ClaimTypes.NameIdentifier,
            user.Id),

        new Claim(
            ClaimTypes.Email,
            user.Email ?? ""),

        new Claim(
            ClaimTypes.Name,
            user.UserName ?? ""),

        new Claim(
            "FullName",
            user.FUllName ?? "")
    };

            // إضافة Roles كـ Claims
            //foreach (var role in roles)
            //{
            //    claims.Add(
            //        new Claim(
            //            ClaimTypes.Role,
            //            role));
            //}

            // إنشاء JWT
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]!));

            var token = new JwtSecurityToken(
                issuer: _configuration["Jwt:Issuer"],
                audience: _configuration["Jwt:Audience"],
                claims: claims, expires: DateTime.UtcNow.AddHours(2),
                signingCredentials: new SigningCredentials(key, SecurityAlgorithms.HmacSha256));
            // تحويل JWT إلى String
            var tokenString = new JwtSecurityTokenHandler() .WriteToken(token);
            // إرجاع Token + Expiration
            return Ok(new 
            { 
                token = tokenString,
                expiration = token.ValidTo,
                Message = "Register completed successfully"
            });
        }



        [HttpGet("GoogleLogin")]
        public IActionResult GoogleLogin(string returnUrl)
        {
            var redirectUrl = Url.Action(
                "GoogleCallback",
                "Auth",
                new { returnUrl },
                Request.Scheme);

            var properties =
                _signInManager.ConfigureExternalAuthenticationProperties(
                    "Google",
                    redirectUrl);

            return Challenge(properties, "Google");
        }


        [HttpGet("GoogleCallback")]
        public async Task<IActionResult> GoogleCallback(string returnUrl)
        {
            var info =
                await _signInManager.GetExternalLoginInfoAsync();

            if (info == null)
            {
                return BadRequest("Google authentication failed.");
            }

            var email =
                info.Principal.FindFirstValue(
                    ClaimTypes.Email);

            var fullName =
                info.Principal.FindFirstValue(
                    ClaimTypes.Name);

            if (string.IsNullOrEmpty(email))
            {
                return BadRequest(
                    "Google account does not have an email.");
            }

            var user =
                await _userManager.FindByEmailAsync(email);

            if (user == null)
            {
                user = new ApplicationUser
                {
                    UserName = email,
                    Email = email,
                    EmailConfirmed = true,
                    FUllName = fullName,
                    Is_Active = true
                };

                var createResult =
                    await _userManager.CreateAsync(user);

                if (!createResult.Succeeded)
                {
                    return BadRequest(createResult.Errors);
                }

                var customer = new Customer
                {
                    UserId = user.Id,
                    IsActive = true
                };

                _context.Customers.Add(customer);

                await _context.SaveChangesAsync();
            }

            // إنشاء JWT
            var roles =
                await _userManager.GetRolesAsync(user);

            var claims = new List<Claim>
    {
        new Claim(
            ClaimTypes.NameIdentifier,
            user.Id),

        new Claim(
            ClaimTypes.Email,
            user.Email ?? ""),

        new Claim(
            "FullName",
            user.FUllName ?? "")
    };

            foreach (var role in roles)
            {
                claims.Add(
                    new Claim(
                        ClaimTypes.Role,
                        role));
            }

            var key =
                new SymmetricSecurityKey(
                    Encoding.UTF8.GetBytes(
                        _configuration["Jwt:Key"]!));

            var token =
                new JwtSecurityToken(
                    issuer:
                        _configuration["Jwt:Issuer"],

                    audience:
                        _configuration["Jwt:Audience"],

                    claims: claims,

                    expires:
                        DateTime.UtcNow.AddHours(2),

                    signingCredentials:
                        new SigningCredentials(
                            key,
                            SecurityAlgorithms.HmacSha256)
                );

            var tokenString =
                new JwtSecurityTokenHandler()
                    .WriteToken(token);

            return Redirect(
        $"{returnUrl}?token={Uri.EscapeDataString(tokenString)}");
        }

    }
}
