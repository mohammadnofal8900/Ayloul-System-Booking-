﻿using System;
using System.Collections.Generic;

namespace First_API.Models
{
    public partial class RoseType
    {
        public RoseType()
        {
            Bookings = new HashSet<Booking>();
        }

        public int RoseTypeId { get; set; }
        public string RoseTypeName { get; set; } = null!;
        public string RoseTypeDescription { get; set; } = null!;
        public string? Img { get; set; }

        public virtual ICollection<Booking> Bookings { get; set; }
    }
}
