﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace First_API.Models
{
    public partial class Service
    {
        public Service()
        {
            BookingServices = new HashSet<BookingService>();
        }
        [Key]
        public int Service_Id { get; set; }
        public string Service_Name { get; set; } = null!;
        public int Price { get; set; }
        public bool? Is_Active { get; set; }
        public string? Img { get; set; }

        public virtual ICollection<BookingService> BookingServices { get; set; }
    }
}
