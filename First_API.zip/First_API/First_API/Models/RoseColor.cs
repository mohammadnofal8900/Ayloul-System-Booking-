﻿using System;
using System.Collections.Generic;

namespace First_API.Models
{
    public partial class RoseColor
    {
        public RoseColor()
        {
            BookingRoseColor1s = new HashSet<Booking>();
            BookingRoseColor2s = new HashSet<Booking>();
        }

        public int RoseColorId { get; set; }
        public string RoseColorName { get; set; } = null!;
        public string? Img { get; set; }

        public virtual ICollection<Booking> BookingRoseColor1s { get; set; }
        public virtual ICollection<Booking> BookingRoseColor2s { get; set; }
    }
}
