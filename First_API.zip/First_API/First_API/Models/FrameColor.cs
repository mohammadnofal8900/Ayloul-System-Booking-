﻿using System;
using System.Collections.Generic;

namespace First_API.Models
{
    public partial class FrameColor
    {
        public FrameColor()
        {
            Bookings = new HashSet<Booking>();
        }

        public int FrameColorId { get; set; }
        public string FrameColorColor { get; set; } = null!;
        public string? Img { get; set; }

        public virtual ICollection<Booking> Bookings { get; set; }
    }
}
