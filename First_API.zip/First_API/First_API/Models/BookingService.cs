﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace First_API.Models
{
    public partial class BookingService
    {
        public int BookingServiceId { get; set; }
        public int BookingId { get; set; }

        [Column("Service_Id")]
        public int ServiceId { get; set; }

        public virtual Booking Booking { get; set; } = null!;
        public virtual Service Service { get; set; } = null!;
    }
}
