﻿using Ayloul.Data;
using System;
using System.Collections.Generic;

namespace First_API.Models
{
    public partial class ChatRoom
    {
        public ChatRoom()
        {
            Messages = new HashSet<Message>();
        }

        public int ChatRoomId { get; set; }
        public string CustomerId { get; set; } = null!;
        public string EmployeeId { get; set; } = null!;
        public DateTime CreatedAt { get; set; }

        public virtual ApplicationUser Customer { get; set; } = null!;
        public virtual ApplicationUser Employee { get; set; } = null!;
        public virtual ICollection<Message> Messages { get; set; }
    }
}
