﻿using Ayloul.Data;
using System;
using System.Collections.Generic;

namespace First_API.Models
{
    public partial class Employee
    {
        public Employee()
        {
            Ratings = new HashSet<Rating>();
        }

        public int EmployeeId { get; set; }
        public string UserId { get; set; } = null!;
        public decimal EmployeeSalary { get; set; }
        public string EmployeeEmail { get; set; } = null!;
        public string MobilePhone { get; set; } = null!;
        public DateTime EmployeeDate { get; set; }
        public bool IsActive { get; set; }
        public string? EmployeeImg { get; set; }
        public int GenderId { get; set; }
        public int DepartmentId { get; set; }
        public int LocationId { get; set; }

        public virtual Department Department { get; set; } = null!;
        public virtual Gender Gender { get; set; } = null!;
        public virtual Location Location { get; set; } = null!;
        public virtual ApplicationUser User { get; set; } = null!;
        public virtual ICollection<Rating> Ratings { get; set; }
    }
}
