﻿using Ayloul.Data;
using System;
using System.Collections.Generic;

namespace First_API.Models
{
    public partial class Customer
    {
        public Customer()
        {
            Bookings = new HashSet<Booking>();
            Ratings = new HashSet<Rating>();
        }

        public int CustomerId { get; set; }
        public string UserId { get; set; } = null!;
        public string? Note { get; set; }
        public bool IsActive { get; set; }

        public virtual ApplicationUser User { get; set; } = null!;
        public virtual ICollection<Booking> Bookings { get; set; }
        public virtual ICollection<Rating> Ratings { get; set; }
    }
}
