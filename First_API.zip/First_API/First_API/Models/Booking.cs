﻿using System;
using System.Collections.Generic;
using static First_API.Data.Dto.BookingViewDto;
using static First_API.Data.Dto.BookingDto;
using First_API.Data.Dto;

namespace First_API.Models
{
    public partial class Booking
    {
        public Booking()
        {
            BookingServices = new HashSet<BookingService>();
            Payments = new HashSet<Payment>();
        }

        public int BookingId { get; set; }
        public string Description { get; set; } = null!;
        public string? Note { get; set; }
        public bool IsActive { get; set; }
        public int? BackgroundId { get; set; }
        public int FrameColorId { get; set; }
        public int LocationId { get; set; }
        public int RoseColor1Id { get; set; }
        public int RoseTypeId { get; set; }
        public int BookingNumber { get; set; }
        public DateTime DateTime { get; set; }
        public int BasePrice { get; set; }
        public string? EventDate { get; set; }
        public string Name { get; set; } = null!;
        public string? NoteImage { get; set; }
        public string PhoneNumber { get; set; } = null!;
        public int? RoseColor2Id { get; set; }
        public decimal TotalPrice { get; set; }
        public int CustomerId { get; set; }
       
        public DateTime OrderDate { get; set; }
        public BookingStatus BookingStatus { get; set; }
        public int? PaymentMethod { get; set; }

        public virtual Background? Background { get; set; }
        public virtual Customer? Customer { get; set; }
        public virtual FrameColor FrameColor { get; set; } = null!;
        public virtual Location Location { get; set; } = null!;
        public virtual RoseColor RoseColor1 { get; set; } = null!;
        public virtual RoseColor? RoseColor2 { get; set; }
        public virtual RoseType RoseType { get; set; } = null!;
        public virtual Rating? Rating { get; set; }
        public virtual ICollection<BookingService> BookingServices { get; set; }
        public virtual ICollection<Payment> Payments { get; set; }
    }
}
