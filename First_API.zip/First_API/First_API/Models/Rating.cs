﻿using System;
using System.Collections.Generic;

namespace First_API.Models
{
    public partial class Rating
    {
        public int RatingId { get; set; }
        public int BookingId { get; set; }
        public int CustomerId { get; set; }
        public int EmployeeId { get; set; }
        public int Stars { get; set; }
        public string? Comment { get; set; }
        public DateTime CreatedAt { get; set; }

        public virtual Booking Booking { get; set; } = null!;
        public virtual Customer Customer { get; set; } = null!;
        public virtual Employee Employee { get; set; } = null!;
    }
}
