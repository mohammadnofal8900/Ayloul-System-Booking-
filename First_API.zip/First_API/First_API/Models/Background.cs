﻿using System;
using System.Collections.Generic;

namespace First_API.Models
{
    public partial class Background
    {
        public Background()
        {
            Bookings = new HashSet<Booking>();
        }

        public int BackgroundId { get; set; }
        public string BackgroundColor { get; set; } = null!;
        public string? Img { get; set; }

        public virtual ICollection<Booking> Bookings { get; set; }
    }
}
