﻿using Ayloul.Data;
using System;
using System.Collections.Generic;

namespace First_API.Models
{
    public partial class Message
    {
        public int MessageId { get; set; }
        public int ChatRoomId { get; set; }
        public string SenderId { get; set; } = null!;
        public string MessageText { get; set; } = null!;
        public DateTime SentAt { get; set; }
        public bool IsRead { get; set; }

        public virtual ChatRoom ChatRoom { get; set; } = null!;
        public virtual ApplicationUser Sender { get; set; } = null!;
    }
}
