﻿using System;
using System.Collections.Generic;

namespace First_API.Models
{
    public partial class Payment
    {
        public int PaymentId { get; set; }
        public int BookingId { get; set; }
        public decimal Amount { get; set; }
        public string Currency { get; set; } = null!;
        public int PaymentMethod { get; set; }
        public string TransactionId { get; set; } = null!;
        public int Status { get; set; }
        public DateTime PaymentDate { get; set; }

        public virtual Booking Booking { get; set; } = null!;
    }
}
