﻿using System;
using System.Collections.Generic;

namespace First_API.Models
{
    public partial class AuditBooking
    {
        public int AuditBookingId { get; set; }
        public int BookingId { get; set; }
        public bool IsActive { get; set; }
        public string UserName { get; set; } = null!;
        public DateTime DeleteDate { get; set; }
        public string? UserId { get; set; }
    }
}
