﻿using System;
using System.Collections.Generic;

namespace First_API.Models
{
    public partial class Location
    {
        public Location()
        {
            Bookings = new HashSet<Booking>();
            Employees = new HashSet<Employee>();
        }

        public int LocationId { get; set; }
        public string City { get; set; } = null!;
        public int Price { get; set; }

        public virtual ICollection<Booking> Bookings { get; set; }
        public virtual ICollection<Employee> Employees { get; set; }
    }
}
