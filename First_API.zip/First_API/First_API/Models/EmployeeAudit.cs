﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace First_API.Models
{
    public partial class EmployeeAudit
    {
        [Key]
        public int AuditId { get; set; }
        public int? EmployeeId { get; set; }
        public string? UserId { get; set; }
        public string? EmployeeEmail { get; set; }
        public string? MobilePhone { get; set; }
        public decimal? EmployeeSalary { get; set; }
        public string? DeletedBy { get; set; }
        public DateTime? DeletedDate { get; set; }
    }
}
